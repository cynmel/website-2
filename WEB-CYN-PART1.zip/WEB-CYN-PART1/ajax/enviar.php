﻿<?php
// if we didn't receive everything
if (empty($_POST['asunto']) || empty($_POST['mensaje'])) {
	echo "Ooops ! Introduzca su dirección de correo electr&oacute;nico y un mensaje.";
	exit();
}
//set info
$destino ="cynmeli.cg@gmail.com";
$desde ="From: " . $_POST['asunto'];
$asunto="Mensaje del Proyecto 2 Forma Contacto";
$mensaje=$_POST['mensaje'];
//funcion mail, permite enviar mensaje, if successful
if (mail($destino,$asunto,$mensaje,$desde)) {
	// echo "Correo Enviado...";
	echo 'Correo enviado!';
}
else {
	echo "Sorry... Problemas al enviar.";
}
?>